﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using RestaurantReviewBusiness;
using RestaurantReviewBusiness.Request;
using RestaurantReviewBusiness.Response;
using RestaurantReviewData.Models;
using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading.Tasks;

namespace RestaurantReviewUnitTests
{
    [ExcludeFromCodeCoverage, TestClass]
    public class RestaurantReviewBusinessTests
    {
        private Mock<RestaurantReviewLogic> _mockLogic = null;

        public const string CityName = "SilverStadt";
        public const string RestaurantName = "The Hotel Saxonburg";
        public const string UserName = "308GT@gmail.com";
        public const string UserReview = "Good food good meat good God let's eat.";

        public RestaurantReviewBusinessTests()
        {
            Services = new ServiceCollection();

            Services.AddDbContext<RestaurantReviewsContext>(opt => opt.UseInMemoryDatabase(databaseName: "InMemoryDb"),
                ServiceLifetime.Transient,
                ServiceLifetime.Transient);

            ServiceProvider = Services.BuildServiceProvider();
            
            _mockLogic = new Mock<RestaurantReviewLogic>();
        }

        #region Properties 

        /// <summary>
        /// The test context.
        /// </summary>
        public TestContext TestContext { get; set; }

        /// <summary>
        /// The services collection
        /// </summary>
        public ServiceCollection Services { get; private set; }
        /// <summary>
        /// The service provider
        /// </summary>
        public ServiceProvider ServiceProvider { get; protected set; }

        /// <summary>
        /// The lifetime is like a box of chocolates
        /// </summary>
        public static bool IsInitialized { get; set; }
        
        #endregion

        [TestInitialize]
        public async Task Initialize()
        {
            if (!IsInitialized)
            {
                await SetupDbContextAsync();
                IsInitialized = true;
            }

            _mockLogic.Setup(l => l.GetContext())
                .Returns(ServiceProvider.GetService<RestaurantReviewsContext>());
        }

        [TestCleanup]
        public void Cleanup()
        {
        }

        /// <summary>
        /// Prepare the in-memory DbContext with data.
        /// </summary>
        /// <returns></returns>
        private async Task SetupDbContextAsync()
        {
            var context = ServiceProvider.GetService<RestaurantReviewsContext>();

            await context.Cities.AddAsync(new City()
            {
                CityId = long.MinValue,
                CityName = CityName
            });
            await context.Restaurants.AddAsync(new Restaurant()
            {
                RestaurantId = long.MinValue,
                RestaurantName = RestaurantName
            });
            await context.CityRestaurants.AddAsync(new CityRestaurant()
            {
                CityRestaurantId = long.MinValue,
                CityId = long.MinValue,
                RestaurantId = long.MinValue
            });
            await context.Users.AddAsync(new User()
            {
                UserId = long.MinValue,
                UserName = UserName
            });
            await context.Reviews.AddAsync(new Review()
            {
                ReviewId = long.MinValue,
                UserReviewId = Guid.NewGuid(),
                UserReview = UserReview
            });
            await context.UserRestaurantReviews.AddAsync(new UserRestaurantReview()
            {
                UserId = long.MinValue,
                RestaurantId = long.MinValue,
                UserReviewId = long.MinValue,
                ReviewId = long.MinValue
            });
            await context.SaveChangesAsync();
        }

        [TestMethod, ExpectedException(typeof(ArgumentException))]
        public async Task TestGetRestaurantsAsync_WhenCityNameNull_ThrowsArguementNullException()
        {
            var result = await _mockLogic.Object.GetRestaurantsAsync(null);
        }

        [TestMethod, ExpectedException(typeof(ArgumentException))]
        public async Task TestGetRestaurantsAsync_WhenCityNameEmptyOrWhitespace_ThrowsArguementNullException()
        {
            var result = await _mockLogic.Object.GetRestaurantsAsync(string.Empty);
        }

        [TestMethod]
        public async Task TestGetRestaurantsAsync_WhenCityMissing_ReturnsNotFound()
        {
            var result = await _mockLogic.Object.GetRestaurantsAsync("MissingStadt");

            Assert.IsNotNull(result);
            Assert.AreEqual(result.StatusCode, (int)HttpStatusCode.NotFound);
            Assert.IsTrue(result.Value is string);

            var response = (string)result.Value;
            TestContext.WriteLine(response);

            Mock.VerifyAll();
        }

        [TestMethod]
        public async Task TestGetRestaurantsAsync_WhenCityNameValid_Success()
        {
            var result = await _mockLogic.Object.GetRestaurantsAsync(CityName);
                
            Assert.IsNotNull(result);
            Assert.AreEqual(result.StatusCode, (int)HttpStatusCode.OK);
            Assert.IsTrue(result.Value is RestaurantsResponse);

            RestaurantsResponse response = (RestaurantsResponse)result.Value;
            Assert.AreEqual(response.CityName, CityName);
            TestContext.WriteLine(JsonConvert.SerializeObject(response, Formatting.Indented));

            Mock.VerifyAll();
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public async Task TestAddRestaurantAsync_WhenParameterNull_ThrowsArguementNullException()
        {
            await _mockLogic.Object.AddRestaurantAsync(null);
        }

        [TestMethod]
        public async Task TestAddRestaurantAsync_WhenRequestExists_Succeeds()
        {
            var result = await _mockLogic.Object.AddRestaurantAsync(new RestaurantRequest()
            {
                CityName = CityName,
                RestaurantName = RestaurantName
            });

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.OK, result.StatusCode);

            Mock.VerifyAll();
        }

        [TestMethod]
        public async Task TestAddRestaurantAsync_WhenRequestValid_Succeeds()
        {
            var result = await _mockLogic.Object.AddRestaurantAsync(new RestaurantRequest()
            {
                CityName = CityName,
                RestaurantName = "A New Restaurant"
            });

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.Created, result.StatusCode);

            Mock.VerifyAll();
        }

        [TestMethod]
        public async Task TestAddRestaurantAsync_WithNewCity_Succeeds()
        {
            var result = await _mockLogic.Object.AddRestaurantAsync(new RestaurantRequest()
            {
                CityName = "AnooCity",
                RestaurantName = "A Noo City Restaurant"
            });

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.Created, result.StatusCode);

            Mock.VerifyAll();
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public async Task TestAddReviewAsync_WhenParameterNull_ThrowsArguementNullException()
        {
            await _mockLogic.Object.AddReviewAsync(null);
        }

        [TestMethod]
        public async Task TestAddReviewAsync_WhenRestaurantMissing_ReturnsNotFound()
        {
            var result = await _mockLogic.Object.AddReviewAsync(new ReviewRequest()
            {
                RestaurantName = "Some Bogus Restaurant Name",
                UserName = UserName,
                UserReview = "The snake they serve here does not tast like chicken."
            });

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.NotFound, result.StatusCode);

            Mock.VerifyAll();
        }

        [TestMethod]
        public async Task TestAddReviewAsync_WhenRequestValid_Succeeds()
        {
            var result = await _mockLogic.Object.AddReviewAsync(new ReviewRequest()
            {
                RestaurantName = RestaurantName,
                UserName = UserName,
                UserReview = "The snake they serve here does not tast like chicken."
            });

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.OK, result.StatusCode);

            Mock.VerifyAll();
        }

        [TestMethod]
        public async Task TestAddReviewAsync_WithNewUser_Succeeds()
        {
            var result = await _mockLogic.Object.AddReviewAsync(new ReviewRequest()
            {
                RestaurantName = RestaurantName,
                UserName = "JohnnyComeLately@gmail.com",
                UserReview = "The snake they serve here does not tast like chicken."
            });

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.OK, result.StatusCode);

            Mock.VerifyAll();
        }

        [TestMethod, ExpectedException(typeof(ArgumentException))]
        public async Task TestGetReviewsAsync_WHenParameterNull_ThrowsArgumentException()
        {
            await _mockLogic.Object.GetReviewsAsync(null);
        }

        [TestMethod]
        public async Task TestGetReviewsAsync_WHenInvalidUserName_ReturnsNotFound()
        {
            var result = await _mockLogic.Object.GetReviewsAsync("SomeoneNobodyKnows");

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [TestMethod]
        public async Task TestGetReviewsAsync_WHenValidUserName_ReturnsSuccess()
        {
            var result = await _mockLogic.Object.GetReviewsAsync(UserName);

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.OK, result.StatusCode);
        }

        [TestMethod]
        public async Task TestDeleteReviewAsync_UserReviewNotValid_ReturnsNotFound()
        {
            var result = await _mockLogic.Object.DeleteReviewAsync(Guid.NewGuid());

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [TestMethod]
        public async Task TestDeleteReviewAsync_WhenUserReviewIdValid_Success()
        {
            var result = await _mockLogic.Object.DeleteReviewAsync(Guid.Empty);

            Assert.IsNotNull(result);
            Assert.AreEqual((int)HttpStatusCode.OK, result.StatusCode);
        }
    }
}
