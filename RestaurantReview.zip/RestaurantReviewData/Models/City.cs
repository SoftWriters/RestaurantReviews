﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RestaurantReviewData.Models
{
    public partial class City
    {
        public City()
        {
            CityRestaurants = new HashSet<CityRestaurant>();
        }

        public long CityId { get; set; }
        public string CityName { get; set; }

        public virtual ICollection<CityRestaurant> CityRestaurants { get; set; }
    }
}
