﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RestaurantReviewData.Models
{
    public partial class UserRestaurantReview
    {
        public long UserReviewId { get; set; }
        public long UserId { get; set; }
        public long RestaurantId { get; set; }
        public long ReviewId { get; set; }

        public virtual Restaurant Restaurant { get; set; }
        public virtual Review Review { get; set; }
        public virtual User User { get; set; }
    }
}
