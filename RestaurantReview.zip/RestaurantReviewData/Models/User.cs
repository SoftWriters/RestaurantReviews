﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RestaurantReviewData.Models
{
    public partial class User
    {
        public User()
        {
            UserRestaurantReviews = new HashSet<UserRestaurantReview>();
        }

        public long UserId { get; set; }
        public string UserName { get; set; }

        public virtual ICollection<UserRestaurantReview> UserRestaurantReviews { get; set; }
    }
}
