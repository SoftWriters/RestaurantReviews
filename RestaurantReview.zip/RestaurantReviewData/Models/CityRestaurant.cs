﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RestaurantReviewData.Models
{
    public partial class CityRestaurant
    {
        public long CityRestaurantId { get; set; }
        public long CityId { get; set; }
        public long RestaurantId { get; set; }

        public virtual City City { get; set; }
        public virtual Restaurant Restaurant { get; set; }
    }
}
