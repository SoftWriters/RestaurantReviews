﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RestaurantReviewData.Models
{
    public partial class Restaurant
    {
        public Restaurant()
        {
            CityRestaurants = new HashSet<CityRestaurant>();
            UserRestaurantReviews = new HashSet<UserRestaurantReview>();
        }

        public long RestaurantId { get; set; }
        public string RestaurantName { get; set; }

        public virtual ICollection<CityRestaurant> CityRestaurants { get; set; }
        public virtual ICollection<UserRestaurantReview> UserRestaurantReviews { get; set; }
    }
}
