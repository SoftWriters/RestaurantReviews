﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

#nullable disable

namespace RestaurantReviewData.Models
{
    public partial class RestaurantReviewsContext : DbContext
    {
        public RestaurantReviewsContext()
        {
        }

        public RestaurantReviewsContext(DbContextOptions<RestaurantReviewsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<City> Cities { get; set; }
        public virtual DbSet<CityRestaurant> CityRestaurants { get; set; }
        public virtual DbSet<Restaurant> Restaurants { get; set; }
        public virtual DbSet<Review> Reviews { get; set; }
        public virtual DbSet<State> States { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<UserRestaurantReview> UserRestaurantReviews { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // add IConfigurationRoot  to get connection string 
                IConfigurationRoot configuration = new ConfigurationBuilder()
                    .AddJsonFile("appsettings.json")
                    .Build();

                optionsBuilder.UseSqlServer(configuration.GetConnectionString("RestaurantReviewConntectionString"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<City>(entity =>
            {
                entity.ToTable("City");

                entity.HasIndex(e => e.CityName, "NonClusteredIndex-20210722-142820")
                    .IsUnique();

                entity.Property(e => e.CityName)
                    .IsRequired()
                    .HasMaxLength(128);
            });

            modelBuilder.Entity<CityRestaurant>(entity =>
            {
                entity.ToTable("CityRestaurant");

                entity.HasIndex(e => new { e.CityId, e.RestaurantId }, "NonClusteredIndex-20210722-145221")
                    .IsUnique();

                entity.HasOne(d => d.City)
                    .WithMany(p => p.CityRestaurants)
                    .HasForeignKey(d => d.CityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CityRestaurant_City");

                entity.HasOne(d => d.Restaurant)
                    .WithMany(p => p.CityRestaurants)
                    .HasForeignKey(d => d.RestaurantId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CityRestaurant_Restaurant");
            });

            modelBuilder.Entity<Restaurant>(entity =>
            {
                entity.ToTable("Restaurant");

                entity.HasIndex(e => e.RestaurantName, "NonClusteredIndex-20210722-210628")
                    .IsUnique();

                entity.Property(e => e.RestaurantName)
                    .IsRequired()
                    .HasMaxLength(128);
            });

            modelBuilder.Entity<Review>(entity =>
            {
                entity.ToTable("Review");

                entity.HasIndex(e => e.UserReviewId, "NonClusteredIndex-20210722-195723")
                    .IsUnique();

                entity.Property(e => e.UserReview)
                    .IsRequired()
                    .HasMaxLength(2048);

                entity.Property(e => e.UserReviewId).HasDefaultValueSql("(newid())");
            });

            modelBuilder.Entity<State>(entity =>
            {
                entity.ToTable("State");

                entity.Property(e => e.StateId).ValueGeneratedNever();

                entity.Property(e => e.StateAbbreviation)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsFixedLength(true);

                entity.Property(e => e.StateName).HasMaxLength(128);
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("User");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(512);
            });

            modelBuilder.Entity<UserRestaurantReview>(entity =>
            {
                entity.HasKey(e => e.UserReviewId)
                    .HasName("PK_UserRestaurantReviews");

                entity.ToTable("UserRestaurantReview");

                entity.HasIndex(e => new { e.UserId, e.RestaurantId, e.ReviewId }, "NonClusteredIndex-20210722-135532");

                entity.HasOne(d => d.Restaurant)
                    .WithMany(p => p.UserRestaurantReviews)
                    .HasForeignKey(d => d.RestaurantId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserRestaurantReviews_Restaurant");

                entity.HasOne(d => d.Review)
                    .WithMany(p => p.UserRestaurantReviews)
                    .HasForeignKey(d => d.ReviewId)
                    .HasConstraintName("FK_UserRestaurantReviews_Review");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserRestaurantReviews)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserRestaurantReviews_User");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
