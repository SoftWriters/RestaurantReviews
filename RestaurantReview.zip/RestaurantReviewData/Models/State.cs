﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RestaurantReviewData.Models
{
    public partial class State
    {
        public int StateId { get; set; }
        public string StateName { get; set; }
        public string StateAbbreviation { get; set; }
    }
}
