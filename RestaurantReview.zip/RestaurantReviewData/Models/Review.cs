﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RestaurantReviewData.Models
{
    public partial class Review
    {
        public Review()
        {
            UserRestaurantReviews = new HashSet<UserRestaurantReview>();
        }

        public long ReviewId { get; set; }
        public Guid UserReviewId { get; set; }
        public string UserReview { get; set; }

        public virtual ICollection<UserRestaurantReview> UserRestaurantReviews { get; set; }
    }
}
