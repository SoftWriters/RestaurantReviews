﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace RestaurantReviewBusiness.Request
{
    /// <summary>
    /// Model for a restaurant review.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ReviewRequest
    {
        /// <summary>
        /// The user's email address which is synonymous with user name in this context.
        /// </summary>
        [Required]
        [EmailAddress]
        public string UserName { get; set; }

        [Required]
        [StringLength(128, MinimumLength = 1)]
        public string RestaurantName { get; set; }

        /// <summary>
        /// The user's review.
        /// </summary>
        [Required]
        [StringLength(2048, MinimumLength = 16)]
        public string UserReview { get; set; }
    }
}
