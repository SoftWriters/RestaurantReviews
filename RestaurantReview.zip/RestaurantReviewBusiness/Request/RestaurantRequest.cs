﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace RestaurantReviewBusiness.Request
{
    /// <summary>
    /// Model for a restaurant
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class RestaurantRequest
    {
        /// <summary>
        /// The city in which the restaurant exists.
        /// </summary>
        [Required]
        [StringLength(128, MinimumLength = 1)]
        public string CityName { get; set; }

        /// <summary>
        /// The name of the restaurant.
        /// </summary>
        [Required]
        [StringLength(128, MinimumLength = 1)]
        public string RestaurantName { get; set; }
    }
}
