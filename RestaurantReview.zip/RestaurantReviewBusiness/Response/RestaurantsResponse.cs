﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace RestaurantReviewBusiness.Response
{
    [ExcludeFromCodeCoverage]
    public class RestaurantsResponse
    {
        public string CityName { get; set; }
        public List<string> RestaurantNames { get; set; }
    }
}
