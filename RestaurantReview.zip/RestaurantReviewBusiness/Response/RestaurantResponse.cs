﻿using System.Diagnostics.CodeAnalysis;

namespace RestaurantReviewBusiness.Response
{
    [ExcludeFromCodeCoverage]
    public class RestaurantResponse
    {
        public string CityName { get; set; }
        public string RestaurantName { get; set; }
    }
}
