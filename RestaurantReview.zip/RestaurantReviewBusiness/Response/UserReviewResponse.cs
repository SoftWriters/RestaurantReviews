﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace RestaurantReviewBusiness.Response
{
    [ExcludeFromCodeCoverage]
    public class UserReviewResponse
    {
        public Guid UserReviewId { get; set; }
        public string UserReview { get; set; }
    }
}
