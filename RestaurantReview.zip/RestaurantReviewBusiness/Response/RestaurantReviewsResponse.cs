﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace RestaurantReviewBusiness.Response
{
    [ExcludeFromCodeCoverage]
    public class RestaurantReviewsResponse
    {
        public string RestaurantName { get; set; }
        public List<UserReviewResponse> UserReviews { get; set; }
    }
}
