﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace RestaurantReviewBusiness.Response
{
    [ExcludeFromCodeCoverage]
    public class ReviewsResponse
    {
        public string UserName { get; set; }
        public List<RestaurantReviewsResponse> RestaurantReviews { get; set; }
    }
}
