﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantReviewBusiness.Request;
using RestaurantReviewBusiness.Response;
using RestaurantReviewData.Models;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace RestaurantReviewBusiness
{
    public class RestaurantReviewLogic
    {
        /// <summary>
        /// Gets the context for the data tier IO.
        /// </summary>
        /// <returns></returns>
        [ExcludeFromCodeCoverage]
        internal virtual RestaurantReviewsContext GetContext()
        {
            return new RestaurantReviewsContext();
        }

        /// <summary>
        /// Get a list of restaurants by city
        /// </summary>
        /// <param name="cityName"></param>
        /// <returns></returns>
        public async Task<ObjectResult> GetRestaurantsAsync(string cityName)
        {
            if (string.IsNullOrWhiteSpace(cityName))
            {
                throw new ArgumentException("Cannot be null or exclusively whitespace.", nameof(cityName));
            }

            using (RestaurantReviewsContext context = GetContext())
            {
                var city = await context.Cities.Where(c => c.CityName == cityName)
                    .Include(c => c.CityRestaurants)
                    .ThenInclude(cr => cr.Restaurant)
                    .FirstOrDefaultAsync();

                if (city == null)
                {
                    return new NotFoundObjectResult(string.Format("The city '{0}' was not found.", cityName));
                }

                var cityRestaurants = new RestaurantsResponse()
                {
                    CityName = city.CityName,
                    RestaurantNames = city.CityRestaurants.Select(c => c.Restaurant.RestaurantName).ToList()
                };

                return new OkObjectResult(cityRestaurants);
            }
        }

        /// <summary>
        /// Post a restaurant that is not in the database
        /// </summary>
        /// <param name="restaurantRequest"></param>
        /// <returns></returns>
        /// <remarks>
        /// This method really needs a transaction. I originally had one in here spanning
        /// several of the saves, but when I wrote the unit tests I found that the calls
        /// to begin the transactions were caused the unit test code to fail.
        /// Because of that, I removed the transactions. Seems like there is always some
        /// issue with mocking the entity framework.
        /// </remarks>
        public async Task<ObjectResult> AddRestaurantAsync(RestaurantRequest restaurantRequest)
        {
            if (restaurantRequest == null)
            {
                throw new ArgumentNullException(nameof(restaurantRequest));
            }

            using (RestaurantReviewsContext context = GetContext())
            {
                var restaurant = await context.Restaurants.FirstOrDefaultAsync(r => r.RestaurantName == restaurantRequest.RestaurantName);
                if (restaurant != null)
                {
                    return new OkObjectResult("The restaurant exists.");
                }

                // This is hacky but then we don't have an API to create a city.
                var city = await GetOrCreateCityAsync(context, restaurantRequest.CityName);

                // Add the restaurant
                restaurant = new Restaurant()
                {
                    RestaurantName = restaurantRequest.RestaurantName
                };
                await context.Restaurants.AddAsync(restaurant);
                await context.SaveChangesAsync();

                // Add the foreign key values
                CityRestaurant cityRestaurant = new CityRestaurant()
                {
                    CityId = city.CityId,
                    RestaurantId = restaurant.RestaurantId,
                };
                await context.CityRestaurants.AddAsync(cityRestaurant);
                await context.SaveChangesAsync();

                return new ObjectResult(new RestaurantResponse()
                {
                    CityName = city.CityName,
                    RestaurantName = restaurant.RestaurantName
                })
                {
                    StatusCode = (int)HttpStatusCode.Created
                };
            }
        }

        /// <summary>
        /// Post a review for a restaurant
        /// </summary>
        /// <param name="reviewRequest"></param>
        /// <returns></returns>
        /// <remarks>
        /// This method really needs a transaction. I originally had one in here spanning
        /// several of the saves, but when I wrote the unit tests I found that the calls
        /// to begin the transactions were caused the unit test code to fail.
        /// Because of that, I removed the transactions. Seems like there is always some
        /// issue with mocking the entity framework.
        /// </remarks>
        public async Task<ObjectResult> AddReviewAsync(ReviewRequest reviewRequest)
        {
            if (reviewRequest == null)
            {
                throw new ArgumentNullException(nameof(reviewRequest));
            }

            using (RestaurantReviewsContext context = GetContext())
            {
                // Get an existing restaurant if it does not exist in the database return 404 (NotFound)
                var restaurant = await GetRestaurantAsync(context, reviewRequest.RestaurantName);
                if (restaurant == null)
                {
                    return new NotFoundObjectResult(string.Format("The restaurant '{0}' was not found.", reviewRequest.RestaurantName));
                }

                // Get an existing or create a new user.
                var user = await GetUserAsync(context, reviewRequest.UserName);

                var review = new Review()
                {
                    UserReview = reviewRequest.UserReview,
                };

                await context.Reviews.AddAsync(review);
                // Must save to have the review id read back.
                await context.SaveChangesAsync();

                var userRestaurantReview = new UserRestaurantReview()
                {
                    UserId = user.UserId,
                    RestaurantId = restaurant.RestaurantId,
                    ReviewId = review.ReviewId
                };
                await context.UserRestaurantReviews.AddAsync(userRestaurantReview);
                await context.SaveChangesAsync();

                return new OkObjectResult(new UserReviewResponse()
                {
                    UserReviewId = review.UserReviewId,
                    UserReview = review.UserReview
                });
            }
        }

        /// <summary>
        /// Get of a list of reviews by user
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public async Task<ObjectResult> GetReviewsAsync(string userName)
        {
            if (string.IsNullOrWhiteSpace(userName))
            {
                throw new ArgumentException("The value cannot be null or only whitespace.", nameof(userName));
            }

            using (RestaurantReviewsContext context = GetContext())
            {
                var user = await context.Users
                    .Where(u => u.UserName == userName)
                    .Include(u => u.UserRestaurantReviews)
                    .ThenInclude(r => r.Restaurant)
                    .Include(u => u.UserRestaurantReviews)
                    .ThenInclude(r => r.Review)
                    .FirstOrDefaultAsync();
                if (user == null)
                {
                    return new NotFoundObjectResult(string.Format("The user '{0}' was not found.", userName));
                }

                ReviewsResponse reviewsResponse = new ReviewsResponse()
                {
                    UserName = user.UserName,
                    RestaurantReviews = user.UserRestaurantReviews
                    .GroupBy(g => g.Restaurant.RestaurantName)
                    .Select(g => new RestaurantReviewsResponse()
                    {
                        RestaurantName = g.Key,
                        UserReviews = g.Select(sg => new UserReviewResponse() { UserReviewId = sg.Review.UserReviewId, UserReview = sg.Review.UserReview }).ToList()
                    })
                    .ToList()
                };

                return new OkObjectResult(reviewsResponse);
            }
        }

        /// <summary>
        /// Delete a review
        /// </summary>
        /// <param name="userReviewId"></param>
        /// <returns></returns>
        public async Task<ObjectResult> DeleteReviewAsync(Guid userReviewId)
        {
            using (RestaurantReviewsContext context = GetContext())
            {
                var review = await context.Reviews.FirstOrDefaultAsync(r => r.UserReviewId == userReviewId);
                if (review == null)
                {
                    return new NotFoundObjectResult(string.Format("The review with user review id '{0}' was not found.", userReviewId));
                }

                context.Reviews.Remove(review);
                await context.SaveChangesAsync();

                return new OkObjectResult(string.Format("The review with id '{0}' has been deleted.", userReviewId));
            }
        }


        /// <summary>
        /// Gets an existing or adds a new city and returns the user entity.
        /// </summary>
        /// <param name="context">
        /// The DbContext.
        /// </param>
        /// <param name="cityName">
        /// The name of the city
        /// </param>
        /// <returns></returns>
        private async Task<City> GetOrCreateCityAsync(RestaurantReviewsContext context, string cityName)
        {
            var city = await context.Cities.FirstOrDefaultAsync(c => c.CityName == cityName);
            if (city != null)
            {
                return city;
            }

            city = new City()
            {
                CityName = cityName
            };

            await context.Cities.AddAsync(city);
            await context.SaveChangesAsync();

            return city;
        }


        /// <summary>
        /// Gets an existing or adds a new user and returns the user entity.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        private async Task<User> GetUserAsync(RestaurantReviewsContext context, string userName)
        {
            User user = await context.Users.FirstOrDefaultAsync(u => u.UserName == userName);
            if (user != null)
            {
                return user;
            }

            user = new User()
            {
                UserName = userName
            };

            await context.Users.AddAsync(user);
            await context.SaveChangesAsync();

            return user;
        }

        /// <summary>
        /// Gets the restaurant entity if it exists.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="restaurantName"></param>
        /// <returns></returns>
        private async Task<Restaurant> GetRestaurantAsync(RestaurantReviewsContext context, string restaurantName)
        {
            return await context.Restaurants.FirstOrDefaultAsync(r => r.RestaurantName == restaurantName);
        }
    }
}