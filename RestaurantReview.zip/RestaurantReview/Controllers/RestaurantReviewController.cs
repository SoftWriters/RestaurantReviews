﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace RestaurantReview.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public partial class RestaurantReviewController : ControllerBase
    {
        private readonly ILogger<RestaurantReviewController> _logger;

        public RestaurantReviewController(ILogger<RestaurantReviewController> logger)
        {
            _logger = logger;
        }
    }
}
