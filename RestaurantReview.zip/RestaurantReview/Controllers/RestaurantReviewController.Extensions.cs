﻿using Microsoft.AspNetCore.Mvc;
using RestaurantReviewBusiness;
using RestaurantReviewBusiness.Request;
using RestaurantReviewBusiness.Response;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Threading.Tasks;

namespace RestaurantReview.Controllers
{
    /// <summary>
    /// The custom implementation for the restaurant review controller.
    /// </summary>
    /// <remarks>
    /// The partial classes were used to clearly delineate my code from auto-generated code.
    /// </remarks>
    public partial class RestaurantReviewController
    {
        private RestaurantReviewLogic _reviewLogic = new RestaurantReviewLogic();

        /// <summary>
        /// Get a list of restaurants by city
        /// </summary>
        /// <param name="cityName"></param>
        /// <returns></returns>
        [SwaggerOperation("Get a list of restaurants by city")]
        [SwaggerResponse((int)HttpStatusCode.OK, Type = typeof(RestaurantsResponse))]
        [SwaggerResponse((int)HttpStatusCode.NotFound, "The provided city was not found.", Type = null)]
        [HttpGet, Route("Restaurants")]
        public async Task< IActionResult> GetRestaurantsAsync([Required] string cityName)
        {
            return await _reviewLogic.GetRestaurantsAsync(cityName);
        }

        /// <summary>
        /// Post a restaurant that is not in the database
        /// </summary>
        /// <param name="restaurantRequest">
        /// The restaurant request body/schema.
        /// </param>
        [SwaggerOperation("Post a restaurant that is not in the database")]
        [SwaggerResponse((int)HttpStatusCode.OK, "The restaurant exists.", Type = null)]
        [SwaggerResponse((int)HttpStatusCode.Created, "The restaurant was created.", Type = typeof(RestaurantResponse))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest,
            "The CityName field is required.</br>" +
            "The field CityName must be a string with a minimum length of 1 and a maximum length of 128.</br>" +
            "The RestaurantName field is required.</br>" +
            "The field RestaurantName must be a string with a minimum length of 1 and a maximum length of 128.",
            Type = null)]
        [HttpPut, Route("Restaurant")]
        public async Task<IActionResult> AddRestaurantAsync([Required] RestaurantRequest restaurantRequest)
        {
            return await _reviewLogic.AddRestaurantAsync(restaurantRequest);
        }

        /// <summary>
        /// Post a review for a restaurant
        /// </summary>
        /// <param name="reviewRequest">
        /// The review request body/schema.
        /// </param>
        [SwaggerOperation("Post a review for a restaurant")]
        [SwaggerResponse((int)HttpStatusCode.OK, Type = typeof(UserReviewResponse))]
        [SwaggerResponse((int)HttpStatusCode.NotFound, "The restaurant provided in the request was not found.", Type = null)]
        [HttpPost, Route("Review")]
        public async Task<IActionResult> AddReviewAsync([Required] ReviewRequest reviewRequest)
        {
            return await _reviewLogic.AddReviewAsync(reviewRequest);
        }

        /// <summary>
        /// Get of a list of reviews by user
        /// </summary>
        /// <param name="userName">
        /// The user's email address which is synonymous with user name in this context.
        /// </param>
        /// <returns></returns>
        [SwaggerOperation("Get of a list of reviews by user")]
        [SwaggerResponse((int)HttpStatusCode.OK, Type = typeof(ReviewsResponse))]
        [SwaggerResponse((int)HttpStatusCode.NotFound, "The provided user was not found.", Type = null)]
        [HttpGet, Route("Reviews")]
        public async Task<IActionResult> GetReviews([Required, EmailAddress] string userName)
        {
            return await _reviewLogic.GetReviewsAsync(userName);
        }

        /// <summary>
        /// Delete a review
        /// </summary>
        /// <param name="userReviewId">
        /// The id of the review to delete.
        /// </param>
        [SwaggerOperation("Delete a review")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        [SwaggerResponse((int)HttpStatusCode.NotFound, "The review specified by the user review id was not found.", Type = null)]
        [HttpDelete, Route("Review")]
        public async Task<IActionResult> DeleteReview([Required] Guid userReviewId)
        {
            return await _reviewLogic.DeleteReviewAsync(userReviewId);
        }

    }
}
