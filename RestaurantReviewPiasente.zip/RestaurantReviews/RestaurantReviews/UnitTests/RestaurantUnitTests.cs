﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using NUnit;
using NUnit.Framework;
using RestaurantReviews.BusinessLogic.Interfaces;
using RestaurantReviews.Data;

namespace RestaurantReviews.UnitTests
{
    [TestFixture]
    public class RestaurantUnitTests
    {
        private IContainer _autofacContainer;

        private IContainer AutofacContainer
        {
            get
            {
                if (_autofacContainer == null)
                {
                    var builder = new ContainerBuilder();

                    // Repositories
                    builder.RegisterType<Data.RestaurantsAndReviews>().As<Data.IRestaurantAndReviews>().InstancePerLifetimeScope();

                    builder.RegisterType<BusinessLogic.RestaurantReviewBusinessLogic>().As<BusinessLogic.Interfaces.IRestaurantReviewBusinessLogic>()
                        .InstancePerLifetimeScope()
                        .PropertiesAutowired(PropertyWiringOptions.AllowCircularDependencies);

                    var container = builder.Build();

                    _autofacContainer = container;
                }

                return _autofacContainer;
            }
        }

        protected IRestaurantAndReviews RestaurantAndReviews
        {
            get
            {
                return AutofacContainer.Resolve<IRestaurantAndReviews>();
            }
        }

   
        protected BusinessLogic.Interfaces.IRestaurantReviewBusinessLogic RestaurantAndReviewsBusinessLogic
        {
            get
            {
                return AutofacContainer.Resolve<IRestaurantReviewBusinessLogic>();
            }
        }


   
        [Test]
        public void TestGetReviewForRestaurant()
        {
            var restaurant = RestaurantAndReviews.GetReviewsForRestaurant(1);
            Assert.IsNotNull(restaurant);
        }
        [Test]

        public void GetRestaurants()
        {
            var restaurant = RestaurantAndReviews.GetRestaurants();
            Assert.IsNotNull(restaurant);
        }
    }
}
