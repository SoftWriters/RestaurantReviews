﻿using System;
using System.Collections.Generic;
using System.Linq;
using RestaurantReviews.BusinessLogic.Interfaces;
using RestaurantReviews.Data;
using RestaurantReviews.Models;

namespace RestaurantReviews.BusinessLogic
{
    public class RestaurantReviewBusinessLogic: IRestaurantReviewBusinessLogic
    {
        private readonly IRestaurantAndReviews _restaurantAndReviews;

        public RestaurantReviewBusinessLogic(IRestaurantAndReviews restaurantAndReviews)
        {
            _restaurantAndReviews = restaurantAndReviews;
        }


        public IEnumerable<Models.RestaurantAndReviews> GetRestaurantsByZipCode(string zipCode)
        {
           var restaurants= _restaurantAndReviews.GetRestaurantsByZipCode(zipCode);
            var restaurantList = new List<Models.RestaurantAndReviews>();
            foreach (var restaurant in restaurants)
            {
                var restaurantToAdd = new Models.RestaurantAndReviews();
                restaurantToAdd.Restaurant = restaurant;
                foreach (var review in restaurant.RestaurantReview)
                {
                    restaurantToAdd.Reviews.Append(review);


                }
               restaurantList.Add(restaurantToAdd);
            }

            return restaurantList;
        }

        public IEnumerable<Models.RestaurantAndReviews> GetRestaurantsByCity(string city)
        {
            var restaurants = _restaurantAndReviews.GetRestaurantsByCity(city);
            var restaurantList = new List<Models.RestaurantAndReviews>();
            foreach (var restaurant in restaurants)
            {
                var restaurantToAdd = new Models.RestaurantAndReviews();
                restaurantToAdd.Restaurant = restaurant;
                foreach (var review in restaurant.RestaurantReview)
                {
                    restaurantToAdd.Reviews.Append(review);
                }
                restaurantList.Add(restaurantToAdd);
            }

            return restaurantList;
        }

        public Models.RestaurantAndReviews GetRestaurantByName(string name)
        {
            var restaurant = _restaurantAndReviews.GetRestaurantByName(name);
             var returnItem = _restaurantAndReviews.GetReviewsForRestaurant(restaurant.Id);   
;            return returnItem;
        }

        public RestaurantAndReviews GetRestaurantById(int id)
        {
            var returnItem = _restaurantAndReviews.GetReviewsForRestaurant(id);
            ; return returnItem;
        }

        public IEnumerable<RestaurantAndReviews> GetRestaurantReviewsByUser(string reviewer)
        {
            var reviews = _restaurantAndReviews.GetReviewsByUser(reviewer);
            var restaurantList = new List<Models.RestaurantAndReviews>();
            foreach (var review in reviews)
            {
                var restaurantToAdd = new Models.RestaurantAndReviews();
                restaurantToAdd.Restaurant = review.Restaurant;
                restaurantToAdd.Reviews.Append(review);
                restaurantList.Add(restaurantToAdd);
            }

            return restaurantList;
        }

        public int AddNewRestaurant(string restaurantName, string addr1, string addr2, string city, string state,
            string zipCode, string phoneNumber, string url)
        {
            if (_restaurantAndReviews.DoesRestaurantExist(restaurantName))
            {
                throw new Exception("Restaurant already exists");
            }

            Models.Restaurant restaurantToAdd = new Models.Restaurant
            {
                RestaurantName = restaurantName,
                Address1 = addr1,
                Address2 = addr2,
                City = city,
                State = state,
                ZipCode = zipCode,
                PhoneNumber = phoneNumber,
                Website = url
            };
           return  _restaurantAndReviews.AddNewRestaurant(restaurantToAdd);

        }

        public int AddNewRestaurantReview(int restaurantId, int rating, string comments, string reviewer)
        {
            var review = new Models.RestaurantReview {RestaurantId = restaurantId};
            CheckReview(rating);
            review.Rating = rating;
            review.Comments = comments;
            review.Reviewer = reviewer;
       
           return  _restaurantAndReviews.AddNewReview(restaurantId,review);
        }

    
        public void DeleteReview(int restaurantId, int reviewId)
        {
            _restaurantAndReviews.DeleteReview(restaurantId,reviewId);
        }
        private void CheckReview(int rating)
        {

            if (rating < 0 || rating > 5)
            {
                throw new Exception("Invalid Rating");
            }
        }
    }

}
