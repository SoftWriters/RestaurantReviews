﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RestaurantReviews.Data;

namespace RestaurantReviews.BusinessLogic.Interfaces
{
    public interface IRestaurantReviewBusinessLogic
    {
        IEnumerable<Models.RestaurantAndReviews> GetRestaurantsByZipCode(string zipCode);
        IEnumerable<Models.RestaurantAndReviews> GetRestaurantsByCity(string city);
        Models.RestaurantAndReviews GetRestaurantByName(string name);
        Models.RestaurantAndReviews GetRestaurantById(int id);
        IEnumerable<Models.RestaurantAndReviews> GetRestaurantReviewsByUser(string reviewer);

        int AddNewRestaurant(string restaurantName, string addr1, string addr2, string city, string state,
            string zipCode, string phoneNumber, string url);

        int AddNewRestaurantReview(int restaurantId, int rating, string comments, string reviewer);
        void DeleteReview(int restaurantId, int reviewId);
    }
}
