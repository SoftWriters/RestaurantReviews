﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using RestaurantReviews.BusinessLogic.Interfaces;

namespace RestaurantReviews.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RestaurantsAndReviewsController : Controller
    {
        private readonly IRestaurantReviewBusinessLogic _restaurantReviewBusinessLogic;

        public RestaurantsAndReviewsController(IRestaurantReviewBusinessLogic restaurantReviewBusinessLogic)
        {
            _restaurantReviewBusinessLogic = restaurantReviewBusinessLogic;
        }

       
        [HttpGet]
        public ActionResult<List<Models.RestaurantAndReviews>> GetByCity(string city)
        {
            return _restaurantReviewBusinessLogic.GetRestaurantsByCity(city).ToList();
        }

        [HttpGet]
        public ActionResult<List<Models.RestaurantAndReviews>> GetByZipCode(string zipCode)
        {
            return _restaurantReviewBusinessLogic.GetRestaurantsByZipCode(zipCode).ToList();
        }


        [HttpGet("{name}", Name = "GetByRestaurantName")]
        public ActionResult<Models.RestaurantAndReviews> GetByRestaurantName(string name)
        {
            return _restaurantReviewBusinessLogic.GetRestaurantByName(name);
        }

        [HttpGet("{id}", Name = "GetByRestaurantId")]
        public ActionResult<Models.RestaurantAndReviews> GetByRestaurantId(int restaurantId)
        {
            return _restaurantReviewBusinessLogic.GetRestaurantById(restaurantId);
        }

        [HttpGet]
        public ActionResult<List<Models.RestaurantAndReviews>> GetReviewsByUser(string user)
        {
            return _restaurantReviewBusinessLogic.GetRestaurantReviewsByUser(user).ToList();
        }

 

        [HttpDelete("{restaurantId,reviewId}")]
        public IActionResult Delete(int restaurantId, int reviewId)
        {
           _restaurantReviewBusinessLogic.DeleteReview(restaurantId,reviewId);
            return NoContent();
        }

        [HttpPut]
        public IActionResult InsertNewRestaurant(string restaurantName,string addr1, string addr2,string city, string state, string zipCode, string phoneNumber, string url)
        {
            _restaurantReviewBusinessLogic.AddNewRestaurant(restaurantName,addr1,addr2,city,state,zipCode,phoneNumber,url);

            return CreatedAtRoute("GetByRestaurantName", new { name = restaurantName});

        }

        [HttpPut]
        public IActionResult InsertNewRestaurant(int restaurantId, int rating, string comments, string reviewer)
        {
            _restaurantReviewBusinessLogic.AddNewRestaurantReview(restaurantId, rating, comments, reviewer);

            return CreatedAtRoute("GetByRestaurantId", new { id = restaurantId });

        }
    }
}