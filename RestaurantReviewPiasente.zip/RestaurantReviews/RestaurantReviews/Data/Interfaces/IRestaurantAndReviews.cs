﻿using System.Collections.Generic;
using RestaurantReviews.Models;

namespace RestaurantReviews.Data
{
    public interface IRestaurantAndReviews
    {
        RestaurantAndReviews GetReviewsForRestaurant(int restaurantId);

        RestaurantAndReviews GetReviewsForRestaurant(string restaurantName);

        IEnumerable<Restaurant> GetRestaurants();

        IEnumerable<Restaurant> GetRestaurantsByCity(string cityName);

        IEnumerable<Restaurant> GetRestaurantsByZipCode(string zipCode);

        void DeleteReview(int restaurantId, int reviewId);

        int AddNewReview(int restaurantId, RestaurantReview review);

        int AddNewRestaurant(Restaurant restaurant);

        IEnumerable<RestaurantReview> GetReviewsByUser(string user);

        bool DoesRestaurantExist(string restaurantName);

        Restaurant GetRestaurantByName(string name);
    }
}
