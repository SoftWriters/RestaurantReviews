﻿using System;
using System.Collections.Generic;
using System.Linq;
using RestaurantReviews.Models;

namespace RestaurantReviews.Data
{
    public class RestaurantsAndReviews: IRestaurantAndReviews

    {
        public RestaurantAndReviews GetReviewsForRestaurant(int restaurantId)
        {
           var restaurantAndReviews = new RestaurantAndReviews();
            using (var db = new RestaurantReviewsContext())
            {
                var restaurant = db.Restaurant.FirstOrDefault(s => s.Id == restaurantId);
                restaurantAndReviews.Restaurant = restaurant;
                foreach (var review in db.RestaurantReview.Where(s=>s.RestaurantId == restaurantId))
              
  {
                    restaurantAndReviews.Reviews.Append(review);
                }
            }

            return restaurantAndReviews;

        }

        public RestaurantAndReviews GetReviewsForRestaurant(string restaurantName)
        {
            var restaurantAndReviews = new RestaurantAndReviews();
            using (var db = new RestaurantReviewsContext())
            {
                var restaurant = db.Restaurant.FirstOrDefault(s => s.RestaurantName.Trim().ToLower() == restaurantName.Trim().ToLower());
                restaurantAndReviews.Restaurant = restaurant;
                foreach (var review in db.RestaurantReview.Where(s => s.Restaurant.RestaurantName.Trim().ToLower() == restaurantName.Trim().ToLower()))

                {
                    restaurantAndReviews.Reviews.Append(review);
                }
            }

            return restaurantAndReviews;
        }

        public IEnumerable<Restaurant> GetRestaurants()
        {
            using (var db = new RestaurantReviewsContext())
            {
                return db.Restaurant.ToList();
            }
        }

        public IEnumerable<Restaurant> GetRestaurantsByCity(string cityName)
        {
            using (var db = new RestaurantReviewsContext())
            {
                return db.Restaurant.Where(s=>
                    string.Equals(s.City.Trim().ToLower(), cityName.Trim().ToLower(), StringComparison.Ordinal)).ToList();
            }
        }

        public IEnumerable<Restaurant> GetRestaurantsByZipCode(string zipCode)
        {
            using (var db = new RestaurantReviewsContext())
            {
                return db.Restaurant.Where(s => string.Equals(s.ZipCode.Trim(), zipCode.Trim(), StringComparison.CurrentCultureIgnoreCase)).ToList();
            }
        }

        public void DeleteReview(int restaurantId, int reviewId)
        {
            using (var db = new RestaurantReviewsContext())
            {
                var review =
                    db.RestaurantReview.FirstOrDefault(s => s.RestaurantId == restaurantId && s.Id == reviewId);
                if (review != null)
                {
                    db.RestaurantReview.Remove(review);
                }

                db.SaveChanges();
            }
        }

        public int AddNewReview(int restaurantId, RestaurantReview review)
        {
            using (var db = new RestaurantReviewsContext())
            {
                if (review.Rating < 0 || review.Rating > 5)
                {
                    throw new Exception("Invalid rating. Ratings must be between 0 and 5 stars");
                }

                db.RestaurantReview.Add(review);

                db.SaveChanges();

                return review.Id;

            }
        }

        public int AddNewRestaurant(Restaurant restaurant)
        {
            using (var db = new RestaurantReviewsContext())
            {
                db.Restaurant.Add(restaurant);

                db.SaveChanges();

                return restaurant.Id;
            }
        }

        public IEnumerable<RestaurantReview> GetReviewsByUser(string user)
        {
            using (var db = new RestaurantReviewsContext())
            {
              return  db.RestaurantReview.Where(s => string.Equals(s.Reviewer.Trim(), user.Trim(), StringComparison.CurrentCultureIgnoreCase)).ToList();
               
            }
        }

        public bool DoesRestaurantExist(string restaurantName)
        {
            using (var db = new RestaurantReviewsContext())
            {
                return db.Restaurant.Any(s => s.RestaurantName.Trim().ToLower() == restaurantName.Trim().ToLower());
            }
        }

        public Restaurant GetRestaurantByName(string name)
        {
 
            using (var db = new RestaurantReviewsContext())
            {
                return db.Restaurant.FirstOrDefault(s => s.RestaurantName.Trim().ToLower() == name.ToLower().Trim());
            }
        }
    }
}
