﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantReviews.Models
{
    public class RestaurantAndReviews
    {
        public Restaurant Restaurant { get; set; }
        public IEnumerable<RestaurantReview> Reviews { get; set; }
    }

    
}
