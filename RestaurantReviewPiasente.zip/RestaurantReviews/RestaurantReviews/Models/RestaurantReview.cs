﻿using System;
using System.Collections.Generic;

namespace RestaurantReviews.Models
{
    public partial class RestaurantReview
    {
        public int Id { get; set; }
        public int RestaurantId { get; set; }
        public int Rating { get; set; }
        public string Comments { get; set; }
        public string Reviewer { get; set; }

        public Restaurant Restaurant { get; set; }
    }
}
