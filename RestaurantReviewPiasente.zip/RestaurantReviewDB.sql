USE [master]
GO

/****** Object:  Database [RestaurantReviews]    Script Date: 11/15/2018 12:19:29 PM ******/
CREATE DATABASE [RestaurantReviews]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'RestaurantReviews', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\RestaurantReviews.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'RestaurantReviews_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\RestaurantReviews_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO

ALTER DATABASE [RestaurantReviews] SET COMPATIBILITY_LEVEL = 140
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [RestaurantReviews].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [RestaurantReviews] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [RestaurantReviews] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [RestaurantReviews] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [RestaurantReviews] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [RestaurantReviews] SET ARITHABORT OFF 
GO

ALTER DATABASE [RestaurantReviews] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [RestaurantReviews] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [RestaurantReviews] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [RestaurantReviews] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [RestaurantReviews] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [RestaurantReviews] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [RestaurantReviews] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [RestaurantReviews] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [RestaurantReviews] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [RestaurantReviews] SET  DISABLE_BROKER 
GO

ALTER DATABASE [RestaurantReviews] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [RestaurantReviews] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [RestaurantReviews] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [RestaurantReviews] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [RestaurantReviews] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [RestaurantReviews] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [RestaurantReviews] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [RestaurantReviews] SET RECOVERY SIMPLE 
GO

ALTER DATABASE [RestaurantReviews] SET  MULTI_USER 
GO

ALTER DATABASE [RestaurantReviews] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [RestaurantReviews] SET DB_CHAINING OFF 
GO

ALTER DATABASE [RestaurantReviews] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO

ALTER DATABASE [RestaurantReviews] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO

ALTER DATABASE [RestaurantReviews] SET DELAYED_DURABILITY = DISABLED 
GO

ALTER DATABASE [RestaurantReviews] SET QUERY_STORE = OFF
GO

ALTER DATABASE [RestaurantReviews] SET  READ_WRITE 
GO


USE [RestaurantReviews]
GO

/****** Object:  Table [dbo].[Restaurant]    Script Date: 11/15/2018 12:19:48 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Restaurant](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RestaurantName] [varchar](100) NOT NULL,
	[Address1] [varchar](50) NOT NULL,
	[Address2] [varchar](50)  NULL,
	[City] [varchar](100) NULL,
	[State] [varchar](2) NOT NULL,
	[ZipCode] [varchar](5) NOT NULL,
	[PhoneNumber] [varchar](10) NOT NULL,
	[Website] [varchar](100)  NULL,
 CONSTRAINT [PK_Restaurant] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

USE [RestaurantReviews]
GO

/****** Object:  Table [dbo].[RestaurantReview]    Script Date: 11/15/2018 12:20:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RestaurantReview](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RestaurantId] [int] NOT NULL,
	[Rating] [int] NOT NULL,
	[Comments] [varchar](max) NULL,
	[Reviewer] [varchar](100) NOT NULL,
 CONSTRAINT [PK_RestaurantReview] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[RestaurantReview]  WITH CHECK ADD  CONSTRAINT [FK_RestaurantReview_Restaurant] FOREIGN KEY([RestaurantId])
REFERENCES [dbo].[Restaurant] ([Id])
GO

ALTER TABLE [dbo].[RestaurantReview] CHECK CONSTRAINT [FK_RestaurantReview_Restaurant]
GO

